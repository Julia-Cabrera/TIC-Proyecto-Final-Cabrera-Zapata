﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cine
{
    public partial class Form_horarios : Form
    {
        public Form_horarios()
        {
            InitializeComponent();
        }
        acciones c = new acciones();
        private void btn_salirH_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_mostrarH_Click(object sender, EventArgs e)
        {
            dgv_horas.DataSource = c.MostrarHorarios();
        }

        private void btn_insertarH_Click(object sender, EventArgs e)
        {
            c.insertar_horario(TimeSpan.Parse(txt_hora.Text));
            dgv_horas.DataSource = c.MostrarHorarios();
        }

        private void btn_actualiarH_Click(object sender, EventArgs e)
        {
            c.actualizar_horario(int.Parse(txt_idhora.Text), TimeSpan.Parse(txt_hora.Text));
                dgv_horas.DataSource = c.MostrarHorarios();
        }

        private void btn_limpiarH_Click(object sender, EventArgs e)
        {
            txt_idhora.Text = "";
            txt_hora.Text = "";
        }

        private void dgv_horas_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_idhora.Text = dgv_horas.CurrentRow.Cells[0].Value.ToString();
            txt_hora.Text = dgv_horas.CurrentRow.Cells[1].Value.ToString();
        }
        //codigo PNG
        private void btn_pngC_Click(object sender, EventArgs e)
        {
            
            int height = dgv_horas.Height;
            dgv_horas.Height = dgv_horas.RowCount * dgv_horas.RowTemplate.Height;

            Bitmap bitmap = new Bitmap(this.dgv_horas.Width, this.dgv_horas.Height);
            dgv_horas.DrawToBitmap(bitmap, new Rectangle(0, 0,
                this.dgv_horas.Width, this.dgv_horas.Height));

            dgv_horas.Height = height;

            bitmap.Save(@"C:\Users\alexz\Desktop\Universidad\DataGridViewHorarios.png");
            MessageBox.Show("Procedimiento terminado");
        }
        //codigo cvs
        private void btn_csvH_Click(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "CVS (*.cvs)|*.cvs";
            SFD.FileName = "cvsarchivo.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (SFD.ShowDialog() == DialogResult.OK)
            {
                writeCSV(dgv_horas, SFD.FileName);
            }
            writeCSV(dgv_horas, SFD.FileName);
        }
        //metodo cvs
        public void writeCSV(DataGridView gridIn, string outputFile)
        {
            
            if (gridIn.RowCount > 0)
            {
                string value = "";
                DataGridViewRow dr = new DataGridViewRow();
                StreamWriter swOut = new StreamWriter(outputFile);

                
                for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                {
                    if (i > 0)
                    {
                        swOut.Write(",");
                    }
                    swOut.Write(gridIn.Columns[i].HeaderText);
                }

                swOut.WriteLine();

                
                for (int j = 0; j <= gridIn.Rows.Count - 1; j++)
                {
                    if (j > 0)
                    {
                        swOut.WriteLine();
                    }

                    dr = gridIn.Rows[j];

                    for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                    {
                        if (i > 0)
                        {
                            swOut.Write(",");
                        }

                        value = dr.Cells[i].Value.ToString();
                        //replace comma's with spaces
                        value = value.Replace(',', ' ');
                        //replace embedded newlines with spaces
                        value = value.Replace(Environment.NewLine, " ");

                        swOut.Write(value);
                    }
                }
                swOut.Close();
                MessageBox.Show("Se guardo");
            }
        }
        //codigo TXT
        private void btn_txtNotasH_Click(object sender, EventArgs e)
        {
            TextWriter sw = new StreamWriter(@"C:\Users\alexz\Desktop\Universidad\Horarios.txt");
            int rowcount = dgv_horas.Rows.Count;

            for (int i = 0; i < rowcount; i++)
            {
                sw.WriteLine(dgv_horas.Rows[i].Cells[0].Value.ToString() + "\t"
                             + dgv_horas.Rows[i].Cells[1].Value.ToString() + "\t"
                              + dgv_horas.Rows[i].Cells[2].Value.ToString() + "\t");
                              
            }
            sw.Close();
            MessageBox.Show("Datos Exportados correctamente");
        }
        //codigo word
        private void btn_wordH_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Word Documents (*.doc)|*.doc";
            sfd.FileName = "export.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportarDgvAWord(dgv_horas, sfd.FileName);
            }

        }
        //metodo word
        private void ExportarDgvAWord(DataGridView dGV, string filename)
        {
            string stOutput = "";
            string sHeaders = "";
            for (int j = 0; j < dGV.Columns.Count; j++)
                sHeaders = sHeaders.ToString() + Convert.ToString(dGV.Columns[j].HeaderText) + "\t";
            stOutput += sHeaders + "\r\n";

            for (int i = 0; i < dGV.RowCount; i++)
            {
                string stLine = "";

                for (int j = 0; j < dGV.Rows[i].Cells.Count; j++)
                    stLine = stLine.ToString() + Convert.ToString(dGV.Rows[i].Cells[j].Value) + "\t";
                stOutput += stLine + "\r\n";
            }
            Encoding utf16 = Encoding.GetEncoding(1254);
            byte[] output = utf16.GetBytes(stOutput);
            FileStream fs = new FileStream(filename, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(output, 0, output.Length); //write the encoded file
            bw.Flush();
            bw.Close();
            fs.Close();
        }
        //excel
        private void btn_excelH_Click(object sender, EventArgs e)
        {
            ExportarDatos(dgv_horas);       
        }
        //metodo excel

        public void ExportarDatos(DataGridView datalistado)
        {
            Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

            exportarexcel.Application.Workbooks.Add(true);

            int indicecolumn = 0;
            foreach (DataGridViewColumn columna in datalistado.Columns)
            {
                indicecolumn++;

                exportarexcel.Cells[1, indicecolumn] = columna.Name;
            }
            int indicefila = 0;
            foreach (DataGridViewRow fila in datalistado.Rows)
            {
                indicefila++;
                indicecolumn = 0;

                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    indicecolumn++;
                    exportarexcel.Cells[indicefila + 1, indicecolumn] = fila.Cells[columna.Name].Value;
                }
            }
            exportarexcel.Visible = true;
        }
    }
}
