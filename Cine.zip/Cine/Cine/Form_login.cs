﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cine
{
    public partial class Form_login : Form
    {
        public Form_login()
        {
            InitializeComponent();
        }
        clase_login sesion = new clase_login();
        int i = 2;
        private void Form_login_Load(object sender, EventArgs e)
        {

        }

        private void btn_ingresar_Click(object sender, EventArgs e)
        {
            i = sesion.inicio_sesion(txt_user.Text.TrimEnd(), txt_contra.Text.TrimEnd());
            if (txt_user.Text== string.Empty)
            {
                MessageBox.Show("Escriba el usuario");
            }
            if(txt_contra.Text== string.Empty)
            {
                MessageBox.Show("Escribe la contraseña");
            }
            if (i == 1)
            {
                this.Hide();
                Menu_cine men = new Menu_cine();
                men.ShowDialog();
            }
        }

        private void btn_salir_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
