﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cine
{
    public partial class Form_cartelera : Form
    {
        public Form_cartelera()
        {
            InitializeComponent();
        }
        acciones d = new acciones();
        private void btn_salirS_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_mostrarC_Click(object sender, EventArgs e)
        {
            dgv_carte.DataSource = d.MostrarCartelera();
        }

        private void btn_insertarC_Click(object sender, EventArgs e)
        {
            d.insertar_cartelera(int.Parse(txt_idSala.Text), int.Parse(txt_idHoras.Text), int.Parse(txt_idPel.Text));
            dgv_carte.DataSource = d.MostrarCartelera();
        }

        private void btn_limpiarC_Click(object sender, EventArgs e)
        {
            txt_idCart.Text = "";
            txt_idHoras.Text = "";
            txt_idPel.Text = "";
            txt_idSala.Text = "";

        }

        private void dgv_carte_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_idCart.Text = dgv_carte.CurrentRow.Cells[0].Value.ToString();
            txt_idSala.Text = dgv_carte.CurrentRow.Cells[1].Value.ToString();
            txt_idHoras.Text = dgv_carte.CurrentRow.Cells[2].Value.ToString();
            txt_idPel.Text = dgv_carte.CurrentRow.Cells[3].Value.ToString();
        }

        private void btn_pngC_Click(object sender, EventArgs e)
        {
           
            int height = dgv_carte.Height;
            dgv_carte.Height = dgv_carte.RowCount * dgv_carte.RowTemplate.Height;

            Bitmap bitmap = new Bitmap(this.dgv_carte.Width, this.dgv_carte.Height);
            dgv_carte.DrawToBitmap(bitmap, new Rectangle(0, 0,
                this.dgv_carte.Width, this.dgv_carte.Height));

            dgv_carte.Height = height;

            bitmap.Save(@"C:\Users\alexz\Desktop\Universidad\DataGridViewCartelera.png");
            MessageBox.Show("Procedimiento terminado");
        }

        private void btn_csvC_Click(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "CVS (*.cvs)|*.cvs";
            SFD.FileName = "cvsarchivo.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (SFD.ShowDialog() == DialogResult.OK)
            {
                writeCSV(dgv_carte, SFD.FileName);
            }
            writeCSV(dgv_carte, SFD.FileName);
        }
      
        public void writeCSV(DataGridView gridIn, string outputFile)
        {
            //test to see if the DataGridView has any rows
            if (gridIn.RowCount > 0)
            {
                string value = "";
                DataGridViewRow dr = new DataGridViewRow();
                StreamWriter swOut = new StreamWriter(outputFile);

                //write header rows to csv
                for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                {
                    if (i > 0)
                    {
                        swOut.Write(",");
                    }
                    swOut.Write(gridIn.Columns[i].HeaderText);
                }

                swOut.WriteLine();

                //write DataGridView rows to csv
                for (int j = 0; j <= gridIn.Rows.Count - 1; j++)
                {
                    if (j > 0)
                    {
                        swOut.WriteLine();
                    }

                    dr = gridIn.Rows[j];

                    for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                    {
                        if (i > 0)
                        {
                            swOut.Write(",");
                        }

                        value = dr.Cells[i].Value.ToString();
                        //replace comma's with spaces
                        value = value.Replace(',', ' ');
                        //replace embedded newlines with spaces
                        value = value.Replace(Environment.NewLine, " ");

                        swOut.Write(value);
                    }
                }
                swOut.Close();
                MessageBox.Show("Se guardo");
            }
        }

        private void btn_excelC_Click(object sender, EventArgs e)
        {
            ExportarDatos(dgv_carte);

        }
        public void ExportarDatos(DataGridView datalistado)
        {
            Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

            exportarexcel.Application.Workbooks.Add(true);

            int indicecolumn = 0;
            foreach (DataGridViewColumn columna in datalistado.Columns)
            {
                indicecolumn++;

                exportarexcel.Cells[1, indicecolumn] = columna.Name;
            }
            int indicefila = 0;
            foreach (DataGridViewRow fila in datalistado.Rows)
            {
                indicefila++;
                indicecolumn = 0;

                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    indicecolumn++;
                    exportarexcel.Cells[indicefila + 1, indicecolumn] = fila.Cells[columna.Name].Value;
                }
            }
            exportarexcel.Visible = true;
        }

        private void btn_txtNotasC_Click(object sender, EventArgs e)
        {
            TextWriter sw = new StreamWriter(@"C:\Users\alexz\Desktop\Universidad\Cartelera.txt");
            int rowcount = dgv_carte.Rows.Count;

            for (int i = 0; i < rowcount; i++)
            {
                sw.WriteLine(dgv_carte.Rows[i].Cells[0].Value.ToString() + "\t"
                             + dgv_carte.Rows[i].Cells[1].Value.ToString() + "\t"
                              + dgv_carte.Rows[i].Cells[2].Value.ToString() + "\t"
                              + dgv_carte.Rows[i].Cells[3].Value.ToString() + "\t"
                               + dgv_carte.Rows[i].Cells[4].Value.ToString() + "\t");
            }
            sw.Close();
            MessageBox.Show("Datos Exportados correctamente");
        }

        private void btn_wordC_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Word Documents (*.doc)|*.doc";
            sfd.FileName = "export.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportarWord(dgv_carte, sfd.FileName);
            }
        }
        private void ExportarWord(DataGridView dGV, string filename)
        {
            string stOutput = "";
            string sHeaders = "";
            for (int j = 0; j < dGV.Columns.Count; j++)
                sHeaders = sHeaders.ToString() + Convert.ToString(dGV.Columns[j].HeaderText) + "\t";
            stOutput += sHeaders + "\r\n";

            for (int i = 0; i < dGV.RowCount; i++)
            {
                string stLine = "";

                for (int j = 0; j < dGV.Rows[i].Cells.Count; j++)
                    stLine = stLine.ToString() + Convert.ToString(dGV.Rows[i].Cells[j].Value) + "\t";
                stOutput += stLine + "\r\n";
            }
            Encoding utf16 = Encoding.GetEncoding(1254);
            byte[] output = utf16.GetBytes(stOutput);
            FileStream fs = new FileStream(filename, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(output, 0, output.Length); //write the encoded file
            bw.Flush();
            bw.Close();
            fs.Close();
        }
    }
}
