﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Cine
{
    public class clase_login
    {

        public int inicio_sesion(string user, string contra)
        {
            ConexionDataContext log = new ConexionDataContext();
            int login = log.sp_InicioSesion(user, contra);
            return login;
        }
    }
}
