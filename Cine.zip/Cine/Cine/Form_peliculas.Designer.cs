﻿namespace Cine
{
    partial class Form_peliculas
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dgv_pelis = new System.Windows.Forms.DataGridView();
            this.btn_mostrarP = new System.Windows.Forms.Button();
            this.btn_insertarP = new System.Windows.Forms.Button();
            this.btn_eliminarP = new System.Windows.Forms.Button();
            this.btn_actualiarP = new System.Windows.Forms.Button();
            this.btn_limpiarP = new System.Windows.Forms.Button();
            this.btn_salirP = new System.Windows.Forms.Button();
            this.label_peli = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.txt_idP = new System.Windows.Forms.TextBox();
            this.txt_duracionP = new System.Windows.Forms.TextBox();
            this.txt_caliP = new System.Windows.Forms.TextBox();
            this.txt_generoP = new System.Windows.Forms.TextBox();
            this.txt_tituloP = new System.Windows.Forms.TextBox();
            this.btn_excel = new System.Windows.Forms.Button();
            this.btn_txtNotas = new System.Windows.Forms.Button();
            this.btn_word = new System.Windows.Forms.Button();
            this.btn_csv = new System.Windows.Forms.Button();
            this.btn_pdf2 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pelis)).BeginInit();
            this.SuspendLayout();
            // 
            // dgv_pelis
            // 
            this.dgv_pelis.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_pelis.Location = new System.Drawing.Point(40, 405);
            this.dgv_pelis.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgv_pelis.Name = "dgv_pelis";
            this.dgv_pelis.RowHeadersWidth = 62;
            this.dgv_pelis.Size = new System.Drawing.Size(946, 231);
            this.dgv_pelis.TabIndex = 0;
            this.dgv_pelis.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_pelis_CellClick);
            // 
            // btn_mostrarP
            // 
            this.btn_mostrarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_mostrarP.ForeColor = System.Drawing.Color.White;
            this.btn_mostrarP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_mostrarP.Location = new System.Drawing.Point(40, 259);
            this.btn_mostrarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_mostrarP.Name = "btn_mostrarP";
            this.btn_mostrarP.Size = new System.Drawing.Size(158, 63);
            this.btn_mostrarP.TabIndex = 1;
            this.btn_mostrarP.Text = "Mostrar";
            this.btn_mostrarP.UseVisualStyleBackColor = true;
            this.btn_mostrarP.Click += new System.EventHandler(this.btn_mostrarP_Click);
            // 
            // btn_insertarP
            // 
            this.btn_insertarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_insertarP.ForeColor = System.Drawing.Color.White;
            this.btn_insertarP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_insertarP.Location = new System.Drawing.Point(206, 259);
            this.btn_insertarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_insertarP.Name = "btn_insertarP";
            this.btn_insertarP.Size = new System.Drawing.Size(158, 63);
            this.btn_insertarP.TabIndex = 2;
            this.btn_insertarP.Text = "Insertar";
            this.btn_insertarP.UseVisualStyleBackColor = true;
            this.btn_insertarP.Click += new System.EventHandler(this.btn_insertarP_Click);
            // 
            // btn_eliminarP
            // 
            this.btn_eliminarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_eliminarP.ForeColor = System.Drawing.Color.White;
            this.btn_eliminarP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_eliminarP.Location = new System.Drawing.Point(372, 259);
            this.btn_eliminarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_eliminarP.Name = "btn_eliminarP";
            this.btn_eliminarP.Size = new System.Drawing.Size(158, 63);
            this.btn_eliminarP.TabIndex = 3;
            this.btn_eliminarP.Text = "Eliminar";
            this.btn_eliminarP.UseVisualStyleBackColor = true;
            this.btn_eliminarP.Click += new System.EventHandler(this.btn_eliminarP_Click);
            // 
            // btn_actualiarP
            // 
            this.btn_actualiarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_actualiarP.ForeColor = System.Drawing.Color.White;
            this.btn_actualiarP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_actualiarP.Location = new System.Drawing.Point(539, 259);
            this.btn_actualiarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_actualiarP.Name = "btn_actualiarP";
            this.btn_actualiarP.Size = new System.Drawing.Size(158, 63);
            this.btn_actualiarP.TabIndex = 4;
            this.btn_actualiarP.Text = "Actualizar";
            this.btn_actualiarP.UseVisualStyleBackColor = true;
            this.btn_actualiarP.Click += new System.EventHandler(this.btn_actualiarP_Click);
            // 
            // btn_limpiarP
            // 
            this.btn_limpiarP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_limpiarP.ForeColor = System.Drawing.Color.White;
            this.btn_limpiarP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_limpiarP.Location = new System.Drawing.Point(706, 259);
            this.btn_limpiarP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_limpiarP.Name = "btn_limpiarP";
            this.btn_limpiarP.Size = new System.Drawing.Size(158, 63);
            this.btn_limpiarP.TabIndex = 5;
            this.btn_limpiarP.Text = "Limpiar";
            this.btn_limpiarP.UseVisualStyleBackColor = true;
            this.btn_limpiarP.Click += new System.EventHandler(this.btn_limpiarP_Click);
            // 
            // btn_salirP
            // 
            this.btn_salirP.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_salirP.ForeColor = System.Drawing.Color.White;
            this.btn_salirP.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_salirP.Location = new System.Drawing.Point(968, 2);
            this.btn_salirP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_salirP.Name = "btn_salirP";
            this.btn_salirP.Size = new System.Drawing.Size(58, 60);
            this.btn_salirP.TabIndex = 6;
            this.btn_salirP.Text = "x";
            this.btn_salirP.UseVisualStyleBackColor = true;
            this.btn_salirP.Click += new System.EventHandler(this.btn_salirP_Click);
            // 
            // label_peli
            // 
            this.label_peli.AutoSize = true;
            this.label_peli.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.25F);
            this.label_peli.ForeColor = System.Drawing.Color.White;
            this.label_peli.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label_peli.Location = new System.Drawing.Point(416, 14);
            this.label_peli.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_peli.Name = "label_peli";
            this.label_peli.Size = new System.Drawing.Size(203, 52);
            this.label_peli.TabIndex = 7;
            this.label_peli.Text = "Peliculas";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label1.Location = new System.Drawing.Point(92, 111);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(137, 29);
            this.label1.TabIndex = 8;
            this.label1.Text = "Id Pelicula:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label2.Location = new System.Drawing.Point(92, 191);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(82, 29);
            this.label2.TabIndex = 9;
            this.label2.Text = "Titulo:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label3.Location = new System.Drawing.Point(388, 198);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(121, 29);
            this.label3.TabIndex = 10;
            this.label3.Text = "Duracion:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label4.Location = new System.Drawing.Point(388, 114);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(103, 29);
            this.label4.TabIndex = 11;
            this.label4.Text = "Genero:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label5.Location = new System.Drawing.Point(660, 117);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 29);
            this.label5.TabIndex = 12;
            this.label5.Text = "Clasificacion:";
            // 
            // txt_idP
            // 
            this.txt_idP.Location = new System.Drawing.Point(222, 114);
            this.txt_idP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_idP.Name = "txt_idP";
            this.txt_idP.Size = new System.Drawing.Size(114, 26);
            this.txt_idP.TabIndex = 13;
            // 
            // txt_duracionP
            // 
            this.txt_duracionP.Location = new System.Drawing.Point(520, 202);
            this.txt_duracionP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_duracionP.Name = "txt_duracionP";
            this.txt_duracionP.Size = new System.Drawing.Size(140, 26);
            this.txt_duracionP.TabIndex = 14;
            // 
            // txt_caliP
            // 
            this.txt_caliP.Location = new System.Drawing.Point(834, 120);
            this.txt_caliP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_caliP.Name = "txt_caliP";
            this.txt_caliP.Size = new System.Drawing.Size(114, 26);
            this.txt_caliP.TabIndex = 15;
            // 
            // txt_generoP
            // 
            this.txt_generoP.Location = new System.Drawing.Point(488, 117);
            this.txt_generoP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_generoP.Name = "txt_generoP";
            this.txt_generoP.Size = new System.Drawing.Size(128, 26);
            this.txt_generoP.TabIndex = 16;
            // 
            // txt_tituloP
            // 
            this.txt_tituloP.Location = new System.Drawing.Point(183, 191);
            this.txt_tituloP.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_tituloP.Name = "txt_tituloP";
            this.txt_tituloP.Size = new System.Drawing.Size(152, 26);
            this.txt_tituloP.TabIndex = 17;
            // 
            // btn_excel
            // 
            this.btn_excel.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_excel.ForeColor = System.Drawing.Color.White;
            this.btn_excel.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_excel.Location = new System.Drawing.Point(550, 332);
            this.btn_excel.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_excel.Name = "btn_excel";
            this.btn_excel.Size = new System.Drawing.Size(128, 63);
            this.btn_excel.TabIndex = 20;
            this.btn_excel.Text = "excel";
            this.btn_excel.UseVisualStyleBackColor = true;
            this.btn_excel.Click += new System.EventHandler(this.btn_excel_Click);
            // 
            // btn_txtNotas
            // 
            this.btn_txtNotas.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_txtNotas.ForeColor = System.Drawing.Color.White;
            this.btn_txtNotas.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_txtNotas.Location = new System.Drawing.Point(265, 332);
            this.btn_txtNotas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_txtNotas.Name = "btn_txtNotas";
            this.btn_txtNotas.Size = new System.Drawing.Size(128, 63);
            this.btn_txtNotas.TabIndex = 21;
            this.btn_txtNotas.Text = "txt";
            this.btn_txtNotas.UseVisualStyleBackColor = true;
            this.btn_txtNotas.Click += new System.EventHandler(this.btn_txtNotas_Click);
            // 
            // btn_word
            // 
            this.btn_word.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_word.ForeColor = System.Drawing.Color.White;
            this.btn_word.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_word.Location = new System.Drawing.Point(129, 332);
            this.btn_word.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_word.Name = "btn_word";
            this.btn_word.Size = new System.Drawing.Size(128, 63);
            this.btn_word.TabIndex = 22;
            this.btn_word.Text = "Word";
            this.btn_word.UseVisualStyleBackColor = true;
            this.btn_word.Click += new System.EventHandler(this.btn_word_Click);
            // 
            // btn_csv
            // 
            this.btn_csv.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_csv.ForeColor = System.Drawing.Color.White;
            this.btn_csv.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_csv.Location = new System.Drawing.Point(401, 332);
            this.btn_csv.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_csv.Name = "btn_csv";
            this.btn_csv.Size = new System.Drawing.Size(128, 63);
            this.btn_csv.TabIndex = 23;
            this.btn_csv.Text = "csv";
            this.btn_csv.UseVisualStyleBackColor = true;
            this.btn_csv.Click += new System.EventHandler(this.btn_csv_Click);
            // 
            // btn_pdf2
            // 
            this.btn_pdf2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_pdf2.ForeColor = System.Drawing.Color.White;
            this.btn_pdf2.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_pdf2.Location = new System.Drawing.Point(686, 332);
            this.btn_pdf2.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_pdf2.Name = "btn_pdf2";
            this.btn_pdf2.Size = new System.Drawing.Size(128, 63);
            this.btn_pdf2.TabIndex = 24;
            this.btn_pdf2.Text = "PNG";
            this.btn_pdf2.UseVisualStyleBackColor = true;
            this.btn_pdf2.Click += new System.EventHandler(this.btn_pdf2_Click);
            // 
            // Form_peliculas
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.ClientSize = new System.Drawing.Size(1026, 669);
            this.Controls.Add(this.btn_pdf2);
            this.Controls.Add(this.btn_csv);
            this.Controls.Add(this.btn_word);
            this.Controls.Add(this.btn_txtNotas);
            this.Controls.Add(this.btn_excel);
            this.Controls.Add(this.txt_tituloP);
            this.Controls.Add(this.txt_generoP);
            this.Controls.Add(this.txt_caliP);
            this.Controls.Add(this.txt_duracionP);
            this.Controls.Add(this.txt_idP);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_peli);
            this.Controls.Add(this.btn_salirP);
            this.Controls.Add(this.btn_limpiarP);
            this.Controls.Add(this.btn_actualiarP);
            this.Controls.Add(this.btn_eliminarP);
            this.Controls.Add(this.btn_insertarP);
            this.Controls.Add(this.btn_mostrarP);
            this.Controls.Add(this.dgv_pelis);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form_peliculas";
            this.Text = "Form_peliculas";
            this.Load += new System.EventHandler(this.Form_peliculas_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_pelis)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgv_pelis;
        private System.Windows.Forms.Button btn_mostrarP;
        private System.Windows.Forms.Button btn_insertarP;
        private System.Windows.Forms.Button btn_eliminarP;
        private System.Windows.Forms.Button btn_actualiarP;
        private System.Windows.Forms.Button btn_limpiarP;
        private System.Windows.Forms.Button btn_salirP;
        private System.Windows.Forms.Label label_peli;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txt_idP;
        private System.Windows.Forms.TextBox txt_duracionP;
        private System.Windows.Forms.TextBox txt_caliP;
        private System.Windows.Forms.TextBox txt_generoP;
        private System.Windows.Forms.TextBox txt_tituloP;
        private System.Windows.Forms.Button btn_excel;
        private System.Windows.Forms.Button btn_txtNotas;
        private System.Windows.Forms.Button btn_word;
        private System.Windows.Forms.Button btn_csv;
        private System.Windows.Forms.Button btn_pdf2;
    }
}