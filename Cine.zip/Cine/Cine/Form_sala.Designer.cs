﻿namespace Cine
{
    partial class Form_sala
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txt_nom = new System.Windows.Forms.TextBox();
            this.txt_des = new System.Windows.Forms.TextBox();
            this.txt_idSala = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label_sala = new System.Windows.Forms.Label();
            this.btn_salirS = new System.Windows.Forms.Button();
            this.btn_limpiarS = new System.Windows.Forms.Button();
            this.btn_actualiarS = new System.Windows.Forms.Button();
            this.btn_insertarS = new System.Windows.Forms.Button();
            this.btn_mostrarS = new System.Windows.Forms.Button();
            this.dgv_sala = new System.Windows.Forms.DataGridView();
            this.btn_pngS = new System.Windows.Forms.Button();
            this.btn_csvS = new System.Windows.Forms.Button();
            this.btn_wordS = new System.Windows.Forms.Button();
            this.btn_txtNotasS = new System.Windows.Forms.Button();
            this.btn_excelS = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sala)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_nom
            // 
            this.txt_nom.Location = new System.Drawing.Point(477, 135);
            this.txt_nom.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_nom.Name = "txt_nom";
            this.txt_nom.Size = new System.Drawing.Size(152, 26);
            this.txt_nom.TabIndex = 35;
            // 
            // txt_des
            // 
            this.txt_des.Location = new System.Drawing.Point(825, 135);
            this.txt_des.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_des.Name = "txt_des";
            this.txt_des.Size = new System.Drawing.Size(128, 26);
            this.txt_des.TabIndex = 34;
            // 
            // txt_idSala
            // 
            this.txt_idSala.Location = new System.Drawing.Point(171, 135);
            this.txt_idSala.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_idSala.Name = "txt_idSala";
            this.txt_idSala.Size = new System.Drawing.Size(114, 26);
            this.txt_idSala.TabIndex = 31;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label4.Location = new System.Drawing.Point(660, 135);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(153, 29);
            this.label4.TabIndex = 29;
            this.label4.Text = "Descripcion:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label2.Location = new System.Drawing.Point(358, 135);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(110, 29);
            this.label2.TabIndex = 27;
            this.label2.Text = "Nombre:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label1.Location = new System.Drawing.Point(40, 132);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(98, 29);
            this.label1.TabIndex = 26;
            this.label1.Text = "Id Sala:";
            // 
            // label_sala
            // 
            this.label_sala.AutoSize = true;
            this.label_sala.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.25F);
            this.label_sala.ForeColor = System.Drawing.Color.White;
            this.label_sala.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label_sala.Location = new System.Drawing.Point(418, 35);
            this.label_sala.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_sala.Name = "label_sala";
            this.label_sala.Size = new System.Drawing.Size(135, 52);
            this.label_sala.TabIndex = 25;
            this.label_sala.Text = "Salas";
            // 
            // btn_salirS
            // 
            this.btn_salirS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_salirS.ForeColor = System.Drawing.Color.White;
            this.btn_salirS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_salirS.Location = new System.Drawing.Point(968, 2);
            this.btn_salirS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_salirS.Name = "btn_salirS";
            this.btn_salirS.Size = new System.Drawing.Size(58, 60);
            this.btn_salirS.TabIndex = 24;
            this.btn_salirS.Text = "x";
            this.btn_salirS.UseVisualStyleBackColor = true;
            this.btn_salirS.Click += new System.EventHandler(this.btn_salirS_Click);
            // 
            // btn_limpiarS
            // 
            this.btn_limpiarS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_limpiarS.ForeColor = System.Drawing.Color.White;
            this.btn_limpiarS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_limpiarS.Location = new System.Drawing.Point(687, 214);
            this.btn_limpiarS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_limpiarS.Name = "btn_limpiarS";
            this.btn_limpiarS.Size = new System.Drawing.Size(158, 63);
            this.btn_limpiarS.TabIndex = 23;
            this.btn_limpiarS.Text = "Limpiar";
            this.btn_limpiarS.UseVisualStyleBackColor = true;
            this.btn_limpiarS.Click += new System.EventHandler(this.btn_limpiarS_Click);
            // 
            // btn_actualiarS
            // 
            this.btn_actualiarS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_actualiarS.ForeColor = System.Drawing.Color.White;
            this.btn_actualiarS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_actualiarS.Location = new System.Drawing.Point(497, 214);
            this.btn_actualiarS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_actualiarS.Name = "btn_actualiarS";
            this.btn_actualiarS.Size = new System.Drawing.Size(158, 63);
            this.btn_actualiarS.TabIndex = 22;
            this.btn_actualiarS.Text = "Actualizar";
            this.btn_actualiarS.UseVisualStyleBackColor = true;
            this.btn_actualiarS.Click += new System.EventHandler(this.btn_actualiarS_Click);
            // 
            // btn_insertarS
            // 
            this.btn_insertarS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_insertarS.ForeColor = System.Drawing.Color.White;
            this.btn_insertarS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_insertarS.Location = new System.Drawing.Point(305, 214);
            this.btn_insertarS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_insertarS.Name = "btn_insertarS";
            this.btn_insertarS.Size = new System.Drawing.Size(158, 63);
            this.btn_insertarS.TabIndex = 20;
            this.btn_insertarS.Text = "Insertar";
            this.btn_insertarS.UseVisualStyleBackColor = true;
            this.btn_insertarS.Click += new System.EventHandler(this.btn_insertarS_Click);
            // 
            // btn_mostrarS
            // 
            this.btn_mostrarS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_mostrarS.ForeColor = System.Drawing.Color.White;
            this.btn_mostrarS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_mostrarS.Location = new System.Drawing.Point(113, 214);
            this.btn_mostrarS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_mostrarS.Name = "btn_mostrarS";
            this.btn_mostrarS.Size = new System.Drawing.Size(158, 63);
            this.btn_mostrarS.TabIndex = 19;
            this.btn_mostrarS.Text = "Mostrar";
            this.btn_mostrarS.UseVisualStyleBackColor = true;
            this.btn_mostrarS.Click += new System.EventHandler(this.btn_mostrarS_Click);
            // 
            // dgv_sala
            // 
            this.dgv_sala.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_sala.Location = new System.Drawing.Point(124, 398);
            this.dgv_sala.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgv_sala.Name = "dgv_sala";
            this.dgv_sala.RowHeadersWidth = 62;
            this.dgv_sala.Size = new System.Drawing.Size(730, 231);
            this.dgv_sala.TabIndex = 18;
            this.dgv_sala.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_sala_CellClick);
            // 
            // btn_pngS
            // 
            this.btn_pngS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_pngS.ForeColor = System.Drawing.Color.White;
            this.btn_pngS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_pngS.Location = new System.Drawing.Point(700, 303);
            this.btn_pngS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_pngS.Name = "btn_pngS";
            this.btn_pngS.Size = new System.Drawing.Size(128, 63);
            this.btn_pngS.TabIndex = 40;
            this.btn_pngS.Text = "PNG";
            this.btn_pngS.UseVisualStyleBackColor = true;
            this.btn_pngS.Click += new System.EventHandler(this.btn_pngS_Click);
            // 
            // btn_csvS
            // 
            this.btn_csvS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_csvS.ForeColor = System.Drawing.Color.White;
            this.btn_csvS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_csvS.Location = new System.Drawing.Point(415, 303);
            this.btn_csvS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_csvS.Name = "btn_csvS";
            this.btn_csvS.Size = new System.Drawing.Size(128, 63);
            this.btn_csvS.TabIndex = 39;
            this.btn_csvS.Text = "csv";
            this.btn_csvS.UseVisualStyleBackColor = true;
            this.btn_csvS.Click += new System.EventHandler(this.btn_csvS_Click);
            // 
            // btn_wordS
            // 
            this.btn_wordS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_wordS.ForeColor = System.Drawing.Color.White;
            this.btn_wordS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_wordS.Location = new System.Drawing.Point(143, 303);
            this.btn_wordS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_wordS.Name = "btn_wordS";
            this.btn_wordS.Size = new System.Drawing.Size(128, 63);
            this.btn_wordS.TabIndex = 38;
            this.btn_wordS.Text = "Word";
            this.btn_wordS.UseVisualStyleBackColor = true;
            this.btn_wordS.Click += new System.EventHandler(this.btn_wordS_Click);
            // 
            // btn_txtNotasS
            // 
            this.btn_txtNotasS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_txtNotasS.ForeColor = System.Drawing.Color.White;
            this.btn_txtNotasS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_txtNotasS.Location = new System.Drawing.Point(279, 303);
            this.btn_txtNotasS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_txtNotasS.Name = "btn_txtNotasS";
            this.btn_txtNotasS.Size = new System.Drawing.Size(128, 63);
            this.btn_txtNotasS.TabIndex = 37;
            this.btn_txtNotasS.Text = "txt";
            this.btn_txtNotasS.UseVisualStyleBackColor = true;
            this.btn_txtNotasS.Click += new System.EventHandler(this.btn_txtNotasS_Click);
            // 
            // btn_excelS
            // 
            this.btn_excelS.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_excelS.ForeColor = System.Drawing.Color.White;
            this.btn_excelS.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_excelS.Location = new System.Drawing.Point(564, 303);
            this.btn_excelS.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_excelS.Name = "btn_excelS";
            this.btn_excelS.Size = new System.Drawing.Size(128, 63);
            this.btn_excelS.TabIndex = 36;
            this.btn_excelS.Text = "excel";
            this.btn_excelS.UseVisualStyleBackColor = true;
            this.btn_excelS.Click += new System.EventHandler(this.btn_excelS_Click);
            // 
            // Form_sala
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.ClientSize = new System.Drawing.Size(1026, 669);
            this.Controls.Add(this.btn_pngS);
            this.Controls.Add(this.btn_csvS);
            this.Controls.Add(this.btn_wordS);
            this.Controls.Add(this.btn_txtNotasS);
            this.Controls.Add(this.btn_excelS);
            this.Controls.Add(this.txt_nom);
            this.Controls.Add(this.txt_des);
            this.Controls.Add(this.txt_idSala);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.label_sala);
            this.Controls.Add(this.btn_salirS);
            this.Controls.Add(this.btn_limpiarS);
            this.Controls.Add(this.btn_actualiarS);
            this.Controls.Add(this.btn_insertarS);
            this.Controls.Add(this.btn_mostrarS);
            this.Controls.Add(this.dgv_sala);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form_sala";
            this.Text = "Form_sala";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_sala)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_nom;
        private System.Windows.Forms.TextBox txt_des;
        private System.Windows.Forms.TextBox txt_idSala;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label_sala;
        private System.Windows.Forms.Button btn_salirS;
        private System.Windows.Forms.Button btn_limpiarS;
        private System.Windows.Forms.Button btn_actualiarS;
        private System.Windows.Forms.Button btn_insertarS;
        private System.Windows.Forms.Button btn_mostrarS;
        private System.Windows.Forms.DataGridView dgv_sala;
        private System.Windows.Forms.Button btn_pngS;
        private System.Windows.Forms.Button btn_csvS;
        private System.Windows.Forms.Button btn_wordS;
        private System.Windows.Forms.Button btn_txtNotasS;
        private System.Windows.Forms.Button btn_excelS;
    }
}