﻿namespace Cine
{
    partial class Form_horarios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label_horas = new System.Windows.Forms.Label();
            this.btn_salirH = new System.Windows.Forms.Button();
            this.dgv_horas = new System.Windows.Forms.DataGridView();
            this.btn_limpiarH = new System.Windows.Forms.Button();
            this.btn_actualiarH = new System.Windows.Forms.Button();
            this.btn_insertarH = new System.Windows.Forms.Button();
            this.btn_mostrarH = new System.Windows.Forms.Button();
            this.txt_hora = new System.Windows.Forms.TextBox();
            this.txt_idhora = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btn_pngH = new System.Windows.Forms.Button();
            this.btn_csvH = new System.Windows.Forms.Button();
            this.btn_wordH = new System.Windows.Forms.Button();
            this.btn_txtNotasH = new System.Windows.Forms.Button();
            this.btn_excelH = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_horas)).BeginInit();
            this.SuspendLayout();
            // 
            // label_horas
            // 
            this.label_horas.AutoSize = true;
            this.label_horas.Font = new System.Drawing.Font("Microsoft Sans Serif", 22.25F);
            this.label_horas.ForeColor = System.Drawing.Color.White;
            this.label_horas.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label_horas.Location = new System.Drawing.Point(384, 38);
            this.label_horas.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label_horas.Name = "label_horas";
            this.label_horas.Size = new System.Drawing.Size(193, 52);
            this.label_horas.TabIndex = 26;
            this.label_horas.Text = "Horarios";
            // 
            // btn_salirH
            // 
            this.btn_salirH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_salirH.ForeColor = System.Drawing.Color.White;
            this.btn_salirH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_salirH.Location = new System.Drawing.Point(966, 2);
            this.btn_salirH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_salirH.Name = "btn_salirH";
            this.btn_salirH.Size = new System.Drawing.Size(58, 60);
            this.btn_salirH.TabIndex = 27;
            this.btn_salirH.Text = "x";
            this.btn_salirH.UseVisualStyleBackColor = true;
            this.btn_salirH.Click += new System.EventHandler(this.btn_salirH_Click);
            // 
            // dgv_horas
            // 
            this.dgv_horas.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_horas.Location = new System.Drawing.Point(118, 412);
            this.dgv_horas.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.dgv_horas.Name = "dgv_horas";
            this.dgv_horas.RowHeadersWidth = 62;
            this.dgv_horas.Size = new System.Drawing.Size(718, 231);
            this.dgv_horas.TabIndex = 28;
            this.dgv_horas.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_horas_CellClick);
            // 
            // btn_limpiarH
            // 
            this.btn_limpiarH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_limpiarH.ForeColor = System.Drawing.Color.White;
            this.btn_limpiarH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_limpiarH.Location = new System.Drawing.Point(678, 225);
            this.btn_limpiarH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_limpiarH.Name = "btn_limpiarH";
            this.btn_limpiarH.Size = new System.Drawing.Size(158, 63);
            this.btn_limpiarH.TabIndex = 32;
            this.btn_limpiarH.Text = "Limpiar";
            this.btn_limpiarH.UseVisualStyleBackColor = true;
            this.btn_limpiarH.Click += new System.EventHandler(this.btn_limpiarH_Click);
            // 
            // btn_actualiarH
            // 
            this.btn_actualiarH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_actualiarH.ForeColor = System.Drawing.Color.White;
            this.btn_actualiarH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_actualiarH.Location = new System.Drawing.Point(489, 225);
            this.btn_actualiarH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_actualiarH.Name = "btn_actualiarH";
            this.btn_actualiarH.Size = new System.Drawing.Size(158, 63);
            this.btn_actualiarH.TabIndex = 31;
            this.btn_actualiarH.Text = "Actualizar";
            this.btn_actualiarH.UseVisualStyleBackColor = true;
            this.btn_actualiarH.Click += new System.EventHandler(this.btn_actualiarH_Click);
            // 
            // btn_insertarH
            // 
            this.btn_insertarH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_insertarH.ForeColor = System.Drawing.Color.White;
            this.btn_insertarH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_insertarH.Location = new System.Drawing.Point(297, 225);
            this.btn_insertarH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_insertarH.Name = "btn_insertarH";
            this.btn_insertarH.Size = new System.Drawing.Size(158, 63);
            this.btn_insertarH.TabIndex = 30;
            this.btn_insertarH.Text = "Insertar";
            this.btn_insertarH.UseVisualStyleBackColor = true;
            this.btn_insertarH.Click += new System.EventHandler(this.btn_insertarH_Click);
            // 
            // btn_mostrarH
            // 
            this.btn_mostrarH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_mostrarH.ForeColor = System.Drawing.Color.White;
            this.btn_mostrarH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_mostrarH.Location = new System.Drawing.Point(105, 225);
            this.btn_mostrarH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_mostrarH.Name = "btn_mostrarH";
            this.btn_mostrarH.Size = new System.Drawing.Size(158, 63);
            this.btn_mostrarH.TabIndex = 29;
            this.btn_mostrarH.Text = "Mostrar";
            this.btn_mostrarH.UseVisualStyleBackColor = true;
            this.btn_mostrarH.Click += new System.EventHandler(this.btn_mostrarH_Click);
            // 
            // txt_hora
            // 
            this.txt_hora.Location = new System.Drawing.Point(618, 127);
            this.txt_hora.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_hora.Name = "txt_hora";
            this.txt_hora.Size = new System.Drawing.Size(152, 26);
            this.txt_hora.TabIndex = 39;
            // 
            // txt_idhora
            // 
            this.txt_idhora.Location = new System.Drawing.Point(312, 127);
            this.txt_idhora.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.txt_idhora.Name = "txt_idhora";
            this.txt_idhora.Size = new System.Drawing.Size(114, 26);
            this.txt_idhora.TabIndex = 38;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label2.Location = new System.Drawing.Point(500, 127);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(74, 29);
            this.label2.TabIndex = 37;
            this.label2.Text = "Hora:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12.25F);
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.label1.Location = new System.Drawing.Point(182, 124);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(129, 29);
            this.label1.TabIndex = 36;
            this.label1.Text = "Id Horario:";
            // 
            // btn_pngH
            // 
            this.btn_pngH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_pngH.ForeColor = System.Drawing.Color.White;
            this.btn_pngH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_pngH.Location = new System.Drawing.Point(684, 310);
            this.btn_pngH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_pngH.Name = "btn_pngH";
            this.btn_pngH.Size = new System.Drawing.Size(128, 63);
            this.btn_pngH.TabIndex = 60;
            this.btn_pngH.Text = "PNG";
            this.btn_pngH.UseVisualStyleBackColor = true;
            this.btn_pngH.Click += new System.EventHandler(this.btn_pngC_Click);
            // 
            // btn_csvH
            // 
            this.btn_csvH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_csvH.ForeColor = System.Drawing.Color.White;
            this.btn_csvH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_csvH.Location = new System.Drawing.Point(399, 310);
            this.btn_csvH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_csvH.Name = "btn_csvH";
            this.btn_csvH.Size = new System.Drawing.Size(128, 63);
            this.btn_csvH.TabIndex = 59;
            this.btn_csvH.Text = "csv";
            this.btn_csvH.UseVisualStyleBackColor = true;
            this.btn_csvH.Click += new System.EventHandler(this.btn_csvH_Click);
            // 
            // btn_wordH
            // 
            this.btn_wordH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_wordH.ForeColor = System.Drawing.Color.White;
            this.btn_wordH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_wordH.Location = new System.Drawing.Point(127, 310);
            this.btn_wordH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_wordH.Name = "btn_wordH";
            this.btn_wordH.Size = new System.Drawing.Size(128, 63);
            this.btn_wordH.TabIndex = 58;
            this.btn_wordH.Text = "Word";
            this.btn_wordH.UseVisualStyleBackColor = false;
            this.btn_wordH.Click += new System.EventHandler(this.btn_wordH_Click);
            // 
            // btn_txtNotasH
            // 
            this.btn_txtNotasH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_txtNotasH.ForeColor = System.Drawing.Color.White;
            this.btn_txtNotasH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_txtNotasH.Location = new System.Drawing.Point(263, 310);
            this.btn_txtNotasH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_txtNotasH.Name = "btn_txtNotasH";
            this.btn_txtNotasH.Size = new System.Drawing.Size(128, 63);
            this.btn_txtNotasH.TabIndex = 57;
            this.btn_txtNotasH.Text = "txt";
            this.btn_txtNotasH.UseVisualStyleBackColor = true;
            this.btn_txtNotasH.Click += new System.EventHandler(this.btn_txtNotasH_Click);
            // 
            // btn_excelH
            // 
            this.btn_excelH.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.25F);
            this.btn_excelH.ForeColor = System.Drawing.Color.White;
            this.btn_excelH.Image = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.btn_excelH.Location = new System.Drawing.Point(548, 310);
            this.btn_excelH.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_excelH.Name = "btn_excelH";
            this.btn_excelH.Size = new System.Drawing.Size(128, 63);
            this.btn_excelH.TabIndex = 56;
            this.btn_excelH.Text = "excel";
            this.btn_excelH.UseVisualStyleBackColor = true;
            this.btn_excelH.Click += new System.EventHandler(this.btn_excelH_Click);
            // 
            // Form_horarios
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::Cine.Properties.Resources.MicrosoftTeams_image__13_;
            this.ClientSize = new System.Drawing.Size(1026, 669);
            this.Controls.Add(this.btn_pngH);
            this.Controls.Add(this.btn_csvH);
            this.Controls.Add(this.btn_wordH);
            this.Controls.Add(this.btn_txtNotasH);
            this.Controls.Add(this.btn_excelH);
            this.Controls.Add(this.txt_hora);
            this.Controls.Add(this.txt_idhora);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btn_limpiarH);
            this.Controls.Add(this.btn_actualiarH);
            this.Controls.Add(this.btn_insertarH);
            this.Controls.Add(this.btn_mostrarH);
            this.Controls.Add(this.dgv_horas);
            this.Controls.Add(this.btn_salirH);
            this.Controls.Add(this.label_horas);
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.Name = "Form_horarios";
            this.Text = "Form_horarios";
            ((System.ComponentModel.ISupportInitialize)(this.dgv_horas)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label_horas;
        private System.Windows.Forms.Button btn_salirH;
        private System.Windows.Forms.DataGridView dgv_horas;
        private System.Windows.Forms.Button btn_limpiarH;
        private System.Windows.Forms.Button btn_actualiarH;
        private System.Windows.Forms.Button btn_insertarH;
        private System.Windows.Forms.Button btn_mostrarH;
        private System.Windows.Forms.TextBox txt_hora;
        private System.Windows.Forms.TextBox txt_idhora;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btn_pngH;
        private System.Windows.Forms.Button btn_csvH;
        private System.Windows.Forms.Button btn_wordH;
        private System.Windows.Forms.Button btn_txtNotasH;
        private System.Windows.Forms.Button btn_excelH;
    }
}