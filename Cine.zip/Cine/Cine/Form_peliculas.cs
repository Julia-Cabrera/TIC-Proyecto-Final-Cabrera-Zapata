﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;
using Microsoft.Office.Interop.Word;
//using Novacode;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TextBox;
using Rectangle = System.Drawing.Rectangle;

namespace Cine
{
    public partial class Form_peliculas : Form
    {
        public Form_peliculas()
        {
            InitializeComponent();
        }
        acciones a = new acciones();
        tipos_exportaciones ex = new tipos_exportaciones();
        private void btn_salirP_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_mostrarP_Click(object sender, EventArgs e)
        {
            dgv_pelis.DataSource = a.MostrarPeliculas();
        }

        private void btn_insertarP_Click(object sender, EventArgs e)
        {
            a.insertar_pelicula(txt_tituloP.Text, txt_duracionP.Text, txt_generoP.Text, txt_caliP.Text);
            dgv_pelis.DataSource = a.MostrarPeliculas();
        }

        private void btn_eliminarP_Click(object sender, EventArgs e)
        {
            a.eliminar_pelicula(int.Parse(txt_idP.Text));
            dgv_pelis.DataSource = a.MostrarPeliculas();
        }

        private void btn_actualiarP_Click(object sender, EventArgs e)
        {
            a.actualizar_pelicula(int.Parse(txt_idP.Text), txt_tituloP.Text, txt_duracionP.Text, txt_generoP.Text, txt_caliP.Text);
            dgv_pelis.DataSource = a.MostrarPeliculas();
        }

        private void btn_limpiarP_Click(object sender, EventArgs e)
        {
            txt_idP.Text = "";
            txt_tituloP.Text = "";
            txt_generoP.Text = "";
            txt_caliP.Text = "";
            txt_duracionP.Text = "";
        }

        private void dgv_pelis_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txt_idP.Text = dgv_pelis.CurrentRow.Cells[0].Value.ToString();
            txt_tituloP.Text = dgv_pelis.CurrentRow.Cells[1].Value.ToString();
            txt_duracionP.Text = dgv_pelis.CurrentRow.Cells[2].Value.ToString();
            txt_generoP.Text = dgv_pelis.CurrentRow.Cells[3].Value.ToString();
            txt_caliP.Text = dgv_pelis.CurrentRow.Cells[4].Value.ToString();

        }

        private void Form_peliculas_Load(object sender, EventArgs e)
        {
        }

        private void btn_txt_Click(object sender, EventArgs e)
        {

            
        }

        private void btn_pdf_Click(object sender, EventArgs e)
        {
           
        }
        public void ExportarDatos(DataGridView datalistado)
        {
            Microsoft.Office.Interop.Excel.Application exportarexcel = new Microsoft.Office.Interop.Excel.Application();

            exportarexcel.Application.Workbooks.Add(true);

            int indicecolumn = 0;
            foreach (DataGridViewColumn columna in datalistado.Columns)
            {
                indicecolumn++;

                exportarexcel.Cells[1, indicecolumn] = columna.Name;
            }
            int indicefila = 0;
            foreach (DataGridViewRow fila in datalistado.Rows)
            {
                indicefila++;
                indicecolumn = 0;
                    
                foreach (DataGridViewColumn columna in datalistado.Columns)
                {
                    indicecolumn++;
                    exportarexcel.Cells[indicefila + 1, indicecolumn] = fila.Cells[columna.Name].Value;
                }
            }
            exportarexcel.Visible = true;
        }
        private void btn_excel_Click(object sender, EventArgs e)
        {
            ExportarDatos(dgv_pelis);
        }

        private void btn_txtNotas_Click(object sender, EventArgs e)
        {

            TextWriter sw = new StreamWriter(@"C:\Users\alexz\Desktop\Universidad\Peliculas.txt");
            int rowcount = dgv_pelis.Rows.Count;

            for (int i = 0; i < rowcount; i++)
            {
                sw.WriteLine(dgv_pelis.Rows[i].Cells[0].Value.ToString() + "\t"
                             + dgv_pelis.Rows[i].Cells[1].Value.ToString() + "\t"
                              + dgv_pelis.Rows[i].Cells[2].Value.ToString() + "\t"
                              + dgv_pelis.Rows[i].Cells[3].Value.ToString() + "\t"
                              + dgv_pelis.Rows[i].Cells[4].Value.ToString() + "\t"
                               + dgv_pelis.Rows[i].Cells[5].Value.ToString() + "\t");
            }
            sw.Close();
            MessageBox.Show("Datos Exportados correctamente");
        }

        private void btn_word_Click(object sender, EventArgs e)
        {
            SaveFileDialog sfd = new SaveFileDialog();
            sfd.Filter = "Word Documents (*.doc)|*.doc";
            sfd.FileName = "export.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (sfd.ShowDialog() == DialogResult.OK)
            {
                ExportarDgvAWord(dgv_pelis, sfd.FileName);
            }
        }

        private void ExportarDgvAWord(DataGridView dGV, string filename)
        {
            string stOutput = "";
            string sHeaders = "";
            for (int j = 0; j < dGV.Columns.Count; j++)
                sHeaders = sHeaders.ToString() + Convert.ToString(dGV.Columns[j].HeaderText) + "\t";
            stOutput += sHeaders + "\r\n";

            for (int i = 0; i < dGV.RowCount; i++)
            {
                string stLine = "";

                for (int j = 0; j < dGV.Rows[i].Cells.Count; j++)
                    stLine = stLine.ToString() + Convert.ToString(dGV.Rows[i].Cells[j].Value) + "\t";
                stOutput += stLine + "\r\n";
            }
            Encoding utf16 = Encoding.GetEncoding(1254);
            byte[] output = utf16.GetBytes(stOutput);
            FileStream fs = new FileStream(filename, FileMode.Create);
            BinaryWriter bw = new BinaryWriter(fs);
            bw.Write(output, 0, output.Length); //write the encoded file
            bw.Flush();
            bw.Close();
            fs.Close();
        }

        private void btn_csv_Click(object sender, EventArgs e)
        {
            SaveFileDialog SFD = new SaveFileDialog();
            SFD.Filter = "CVS (*.cvs)|*.cvs";
            SFD.FileName = "cvsarchivo.doc"; //aqui le cambio el nombre cuando se abre el save file dialog

            if (SFD.ShowDialog() == DialogResult.OK)
            {
                writeCSV(dgv_pelis, SFD.FileName);
            }
            writeCSV(dgv_pelis, SFD.FileName);
        }
        public void writeCSV(DataGridView gridIn, string outputFile)
        {
            //test to see if the DataGridView has any rows
            if (gridIn.RowCount > 0)
            {
                string value = "";
                DataGridViewRow dr = new DataGridViewRow();
                StreamWriter swOut = new StreamWriter(outputFile);

                //write header rows to csv
                for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                {
                    if (i > 0)
                    {
                        swOut.Write(",");
                    }
                    swOut.Write(gridIn.Columns[i].HeaderText);
                }

                swOut.WriteLine();

                //write DataGridView rows to csv
                for (int j = 0; j <= gridIn.Rows.Count - 1; j++)
                {
                    if (j > 0)
                    {
                        swOut.WriteLine();
                    }

                    dr = gridIn.Rows[j];

                    for (int i = 0; i <= gridIn.Columns.Count - 1; i++)
                    {
                        if (i > 0)
                        {
                            swOut.Write(",");
                        }

                        value = dr.Cells[i].Value.ToString();
                        //replace comma's with spaces
                        value = value.Replace(',', ' ');
                        //replace embedded newlines with spaces
                        value = value.Replace(Environment.NewLine, " ");

                        swOut.Write(value);
                    }
                }
                swOut.Close();
                MessageBox.Show("Se guardo");
            }
        }

        private void btn_pdf2_Click(object sender, EventArgs e)
        {
            //Resize DataGridView to full height.
            int height = dgv_pelis.Height;
            dgv_pelis.Height = dgv_pelis.RowCount * dgv_pelis.RowTemplate.Height;

            //Create a Bitmap and draw the DataGridView on it.
            Bitmap bitmap = new Bitmap(this.dgv_pelis.Width, this.dgv_pelis.Height);
            dgv_pelis.DrawToBitmap(bitmap, new Rectangle(0,0, 
                this.dgv_pelis.Width, this.dgv_pelis.Height));

            //Resize DataGridView back to original height.
            dgv_pelis.Height = height;

            //Save the Bitmap to folder.
            bitmap.Save(@"C:\Users\alexz\Desktop\Universidad\DataGridViewPeli.png");
            MessageBox.Show("Procedimiento terminado");
        }
    }
}
