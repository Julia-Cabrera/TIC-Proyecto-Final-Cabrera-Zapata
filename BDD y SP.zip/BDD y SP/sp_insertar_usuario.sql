use Cine
go

create procedure sp_insertar_usuario
(
@pusuario varchar(25),
@pcontra varchar(25)
)
as
insert into usuarios
(
usuario,
clave
)

values
(
@pusuario,
@pcontra
)