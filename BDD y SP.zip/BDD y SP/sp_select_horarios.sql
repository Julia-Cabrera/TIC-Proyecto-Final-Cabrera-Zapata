use cine 

go

create procedure sp_select_horarios
as
begin
select * from horarios
end 
go