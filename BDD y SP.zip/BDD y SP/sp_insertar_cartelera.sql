use Cine
go

create procedure sp_insertar_cartelera
(
@pid_sala int,
@pid_horarios int,
@pid_peiculas int
)
as
insert into cartelera
(
id_sala,
id_horarios,
id_peliculas
)

values
(
@pid_sala,
@pid_horarios,
@pid_peiculas
)