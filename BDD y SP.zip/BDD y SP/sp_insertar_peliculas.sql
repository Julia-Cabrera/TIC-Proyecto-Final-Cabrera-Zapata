use Cine
go

create procedure sp_insertar_pelicula
(
@ptitulo varchar(50),
@pduracion varchar(5),
@pgenero varchar(25),
@pclasificacion varchar(10)
)
as
insert into peliculas
(
titulo,
duracion,
genero,
clasificacion
)

values
(
@ptitulo,
@pduracion,
@pgenero,
@pclasificacion
)