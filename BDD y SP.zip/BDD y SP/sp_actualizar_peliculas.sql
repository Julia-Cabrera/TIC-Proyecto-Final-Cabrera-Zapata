use Cine
go

create procedure sp_actualizar_peliculas
(
@pid_peliculas int,
@ptitulo varchar(50),
@pduracion varchar(5),
@pgenero varchar(25),
@pclasificacion varchar(10)

)
as 
if exists (Select * from peliculas where (id_peliculas = @pid_peliculas))
Update peliculas
Set titulo = @ptitulo,
duracion = @pduracion,
genero = @pgenero,
clasificacion = @pclasificacion
where id_peliculas = @pid_peliculas
