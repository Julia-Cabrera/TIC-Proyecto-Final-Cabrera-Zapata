Create database Cine

use Cine

create table usuario (
id_usuario int identity(1,1) primary key not null,
usuario varchar(25),
clave varchar(25),
estado bit default 1)

create table sala (
id_sala int identity(1,1) primary key not null,
nombre varchar(50), 
descripcion varchar(50),
estado bit default 1)

create table horarios (
id_horarios int identity(1,1) primary key not null,
hora time,
estado bit default 1)

create table peliculas (
id_peliculas int identity(1,1) primary key not null,
titulo varchar(50),
duracion varchar(5),
genero varchar(25),
clasificacion varchar(10),
estado bit default 1)

create table cartelera (
id_cartelera int identity(1,1),
id_sala int foreign key references sala(id_sala),
id_horarios int foreign key references horarios(id_horarios),
id_peliculas int foreign key references peliculas(id_peliculas),
estado bit default 1)
