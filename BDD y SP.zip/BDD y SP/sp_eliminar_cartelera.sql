use Cine
go

create procedure sp_eliminar_cartelera
(
@pid_cartelera int
)
as 
if EXISTS (SELECT id_cartelera FROM cartelera WHERE (id_cartelera = @pid_cartelera))
Update cartelera
Set estado = 0
where id_cartelera = @pid_cartelera