use cine 

go

create procedure sp_select_cartelera
as
begin
select * from cartelera
end 
go