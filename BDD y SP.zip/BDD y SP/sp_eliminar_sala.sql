use Cine
go

create procedure sp_eliminar_sala
(
@pid_sala int
)
as 
if EXISTS (SELECT id_sala FROM sala WHERE (id_sala = @pid_sala))
Update sala
Set estado = 0
where id_sala = @pid_sala