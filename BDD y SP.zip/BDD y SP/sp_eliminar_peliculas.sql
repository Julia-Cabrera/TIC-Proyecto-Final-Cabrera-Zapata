use Cine
go

create procedure sp_eliminar_pelicula
(
@pid_peliculas int
)
as 
if EXISTS (SELECT id_peliculas FROM peliculas WHERE (id_peliculas = @pid_peliculas))
Update peliculas
Set estado = 0
where id_peliculas = @pid_peliculas