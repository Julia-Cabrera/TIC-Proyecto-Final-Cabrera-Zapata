use Cine
go

create procedure sp_insertar_sala
(
@pnombre varchar(50), 
@pdescripcion varchar(50)
)
as
insert into sala
(
nombre,
descripcion
)

values
(
@pnombre,
@pdescripcion
)