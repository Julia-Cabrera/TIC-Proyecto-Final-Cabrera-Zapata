use Cine
go

create procedure sp_actualizar_cartelera
(
@pid_cartelera int,
@pid_sala int,
@pid_horario int,
@pid_pelicula int
)
as 
if exists (Select * from cartelera where (id_cartelera = @pid_cartelera))
Update cartelera
Set id_sala = @pid_sala,
id_horarios = @pid_horario,
id_peliculas = @pid_pelicula
where id_cartelera = @pid_cartelera