use cine 

go

create procedure sp_select_salas
as
begin
select * from sala
end 
go

