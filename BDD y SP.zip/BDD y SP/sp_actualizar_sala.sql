use Cine
go

create procedure sp_actualizar_sala
(
@pid_sala int,
@pnombre varchar(50),
@pdescripcion varchar(50)
)
as 
if exists (Select * from sala where (id_sala = @pid_sala))
Update sala
Set nombre = @pnombre,
descripcion = @pdescripcion
where id_sala = @pid_sala
