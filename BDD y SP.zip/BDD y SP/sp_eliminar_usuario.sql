use Cine
go

create procedure sp_eliminar_usuario
(
@pid_usuario int
)
as 
if EXISTS (SELECT id_usuario FROM usuario WHERE (id_usuario = @pid_usuario))
Update usuario
Set estado = 0
where id_usuario = @pid_usuario