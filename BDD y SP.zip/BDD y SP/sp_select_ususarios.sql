use Cine
go

create procedure sp_select_usuarios
as
begin
select * from usuario
end
go