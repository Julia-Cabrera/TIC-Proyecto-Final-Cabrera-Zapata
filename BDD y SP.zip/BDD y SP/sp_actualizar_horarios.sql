use Cine
go

create procedure sp_actualizar_horarios
(
@pid_horarios int,
@phora time
)
as 
if exists (Select * from horarios where (id_horarios = @pid_horarios))
Update horarios
Set hora = @phora
where id_horarios = @pid_horarios
