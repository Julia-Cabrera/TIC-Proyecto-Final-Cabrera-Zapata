use cine 

go

create procedure sp_select_peliculas
as
begin
select * from peliculas
end 
go