use Cine
go

create procedure sp_actualizar_usuario
(
@pid_usuario int,
@pusuario varchar(25),
@pclave varchar(25)
)
as 
if exists (Select * from usuario where (id_usuario = @pid_usuario))
Update usuario
Set usuario = @pusuario,
clave = @pclave
where id_usuario = @pid_usuario