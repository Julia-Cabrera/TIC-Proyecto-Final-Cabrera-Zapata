use Cine
go

create procedure sp_eliminar_horario
(
@pid_horario int
)
as 
if EXISTS (SELECT id_horarios FROM horarios WHERE (id_horarios = @pid_horario))
Update horarios
Set estado = 0
where id_horarios = @pid_horario