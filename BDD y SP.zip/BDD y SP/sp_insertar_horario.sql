use Cine
go

create procedure sp_insertar_horarios
(
@phora time
)
as
insert into horarios
(
hora
)

values
(
@phora
)